<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>{{ $DTE['identificacion']['codigoGeneracion'] }} </title>
    <style>

        *{ 
            margin: 0cm; font-family: "Segoe UI",Roboto,"Helvetica Neue","Noto Sans","Liberation Sans",Arial,sans-serif;
        }
        body {
            font-family: serif; 
            margin: 270px 50px 50px 50px;
            font-size: 10px;
        }
        h1,h2,h3,h4,h5,h6{color: #003 !important; }

        .table{width: 100%; border-collapse: collapse; }
        .table th, .table td{
            border-collapse: collapse;
            padding: 5px;
            text-align: left;
        }

        .table.bordered th, .table.bordered td{
            border: 1px solid #aaa;
        }

        /* Propiedades para permitir división de tabla entre páginas */
        .table.bordered {
            page-break-inside: auto;
        }
        
        .table.bordered tr {
            page-break-inside: avoid;
            page-break-after: auto;
        }
        
        .table.bordered thead {
            display: table-header-group;
        }
        
        .table.bordered tfoot {
            display: table-footer-group;
        }
        
        .text-right{
            text-align: right !important;
        }

        .bg-light{
            background-color: #ddd;
        }

        header {
            margin: 50px 50px 0px 50px;
            position: fixed;
        }

    </style>
    
</head>
<body>
    @php
        $tipoModelo = [
            'Modelo Facturación previo',
            'Modelo Facturación diferido'
        ];
        $tipoOperacion = [
            'Transmisión normal',
            'Transmisión por contingencia'
        ];
    @endphp
    @php
        $tipoDocumento = [
                '36',
                '13'
        ];
    @endphp
    <header>
        <table class="table">
            <tbody>
                <tr>
                    <td  style="width: 25%;">
                        {{-- Logo --}}
                        @if ($registro->empresa()->pluck('logo')->first())
                            <img height="130" src="{{ asset('img/'.$registro->empresa()->pluck('logo')->first()) }}" alt="Logo">
                        @endif
                    </td>
                    <td style="width: 50%; text-align: center;">
                        <h2>DOCUMENTO TRIBUTARIO ELECTRÓNICO</h2>
                        <h2>FACTURA</h2>
                    </td>
                    <td style="width: 25%; text-align: right;">
                        {!! '<img id="qrcode" width="130" height="130" src="data:image/png;base64,' . DNS2D::getBarcodePNG($registro->qr, 'QRCODE', 10, 10, array(0,0,0), true) . '" alt="barcode"   />' !!}
                    </td>
                </tr>
            </tbody>
        </table>
        <table class="table bordered">
            <tbody>
                <tr>
                    <td style="width: 50%;">
                        <p><b>Código de Generación:</b> {{ isset($DTE['identificacion']['codigoGeneracion']) ? $DTE['identificacion']['codigoGeneracion'] : '' }}</p>
                        <p><b>Número de Control:</b> {{ isset($DTE['identificacion']['numeroControl']) ? $DTE['identificacion']['numeroControl'] : '' }}</p>
                        <p><b>Sello de Recepción:</b> {{ isset($DTE['sello']) ? $DTE['sello'] : '' }}</p>
                    </td>
                    <td style="width: 50%;">
                        <p><b>Modelo de Facturación:</b> {{ isset($DTE['identificacion']['tipoModelo']) ? $tipoModelo[$DTE['identificacion']['tipoModelo'] - 1] : '' }}</p>
                        <p><b>Tipo de Transmisión:</b> {{ isset($DTE['identificacion']['tipoOperacion']) ? $tipoOperacion[$DTE['identificacion']['tipoOperacion'] - 1] : '' }}</p>
                        <p><b>Fecha y Hora de Generación:</b> 
                            @if (isset($DTE['identificacion']['fecEmi']) && isset($DTE['identificacion']['horEmi']))
                                {{ \Carbon\Carbon::parse($DTE['identificacion']['fecEmi'] . ' ' . $DTE['identificacion']['horEmi'])->format('d/m/Y H:i:s') }}
                            @endif
                        </p>
                    </td>
                </tr>
            </tbody>
        </table>
    </header>

    <table class="table bordered">
        <tbody>
            <tr>
                <td class="bg-light" style="width: 50%;">
                    <h3>Emisor</h3>
                </td>
                <td class="bg-light" style="width: 50%;">
                    <h3>Receptor</h3>
                </td>
            </tr>
            <tr>
                <td style="width: 50%; vertical-align: top;">
                    <p><b>Nombre o razón social: </b>{{ $DTE['emisor']['nombre'] }}</p>
                    <p><b>NIT:</b> {{ $DTE['emisor']['nit'] }}</p>
                    <p><b>NRC:</b> {{ $DTE['emisor']['nrc'] }}</p>
                    <p><b>Act. económica:</b> {{ $DTE['emisor']['descActividad'] }}</p>
                    <p><b>Dirección:</b> 
                        @if (isset($DTE['emisor']['direccion']['complemento']))
                            {{ $DTE['emisor']['direccion']['complemento'] }}
                        @endif
                        {{ $registro->empresa()->pluck('municipio')->first(); }}
                        {{ $registro->empresa()->pluck('departamento')->first(); }}
                    </p>
                    
                    <p><b>Teléfono: </b>{{ $DTE['emisor']['telefono'] }}</p>
                    <p><b>Correo: </b>{{ $DTE['emisor']['correo'] }}</p>
                </td>
                <td style="width: 50%; vertical-align: top;">
                    @if ($DTE['receptor'])
                        <p><b>Nombre o razón social: </b>{{ $DTE['receptor']['nombre'] }}</p>
                        <p><b>Tipo de Documento:</b>
                            @if ($DTE['receptor']['tipoDocumento'] == '36')
                                NIT
                            @endif
                            @if ($DTE['receptor']['tipoDocumento'] == '13')
                                DUI
                            @endif
                            @if ($DTE['receptor']['tipoDocumento'] == '03')
                                Pasaporte
                            @endif
                            @if ($DTE['receptor']['tipoDocumento'] == '02')
                                Carnet de residente
                            @endif
                            @if ($DTE['receptor']['tipoDocumento'] == '37')
                                Otro
                            @endif
                        </p>
                        <p><b>Núm de Documento:</b> {{ $DTE['receptor']['numDocumento'] }}</p>
                        <p><b>Act. económica:</b> {{ $DTE['receptor']['descActividad'] }}</p>
                            <p><b>Dirección:</b> 
                                @if ($registro->id_cliente)
                                    @if (isset($DTE['receptor']['direccion']['complemento']))
                                        {{ $DTE['receptor']['direccion']['complemento'] }}
                                    @endif
                                    {{ $registro->cliente()->pluck('municipio')->first(); }}
                                    {{ $registro->cliente()->pluck('departamento')->first(); }}
                                @endif
                            </p>
                        <p><b>Teléfono: </b>{{ $DTE['receptor']['telefono'] }}</p>
                        <p><b>Correo: </b>{{ $DTE['receptor']['correo'] }}</p>
                    @endif
                </td>
            </tr>
        </tbody>
    </table> 
    <table class="table bordered">
        <thead>
            <tr class="bg-light">
                <th width="3%" class="border-bottom">N°</th>
                <th width="5%" class="border-bottom">Cantidad</th>
                <th width="5%" class="border-bottom">Código</th>
                <th class="border-bottom">Descripción</th>
                <th width="10%" class="border-bottom text-right">Precio Unitario</th>
                <th width="10%" class="border-bottom text-right">Descuento por ítem</th>
                @if ($DTE['resumen']['totalNoGravado'] > 0)
                    <th width="10%" class="border-bottom text-right">Otros Montos no Afectos</th>
                @endif
                <th width="10%" class="border-bottom text-right">Ventas No Sujetas</th>
                <th width="10%" class="border-bottom text-right">Ventas Exentas</th>
                <th width="10%" class="border-bottom text-right">Ventas Gravadas</th>
            </tr>
        </thead>
        <tbody>
            @foreach($DTE['cuerpoDocumento'] as $detalle)
            <tr>
                <td class="border-bottom">   {{ $detalle['numItem']  }}</td>
                <td class="border-bottom">   {{ number_format($detalle['cantidad'] , 4) }}</td>
                <td class="border-bottom">   {{ $detalle['codigo']  }}</td>
                <td class="border-bottom">   {{ $detalle['descripcion']  }}</td>
                <td class="border-bottom text-right">   ${{number_format($detalle['precioUni'] , 4) }}</td>
                <td class="border-bottom text-right">   ${{number_format($detalle['montoDescu'] , 2) }}</td>
                @if ($detalle['noGravado'])
                    <td class="border-bottom text-right">   ${{ number_format($detalle['noGravado'], 2) }}</th>
                @endif
                <td class="border-bottom text-right">   ${{ number_format($detalle['ventaNoSuj'], 2) }}</th>
                <td class="border-bottom text-right">   ${{ number_format($detalle['ventaExenta'], 2) }}</th>
                <td class="border-bottom text-right">   ${{ number_format($detalle['ventaGravada'], 2) }}</th>
            </tr>
            @endforeach
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4"></td>
                <td class="bg-light" colspan="2"><b>Suma de ventas:</b> </td>
                @if ($DTE['resumen']['totalNoGravado'] > 0)
                    <td class="bg-light text-right">${{ number_format($DTE['resumen']['totalNoGravado'], 2) }}</td>
                @endif
                <td class="bg-light text-right">${{ number_format($DTE['resumen']['totalNoSuj'], 2) }}</td>
                <td class="bg-light text-right">${{ number_format($DTE['resumen']['totalExenta'], 2) }}</td>
                <td class="bg-light text-right">${{ number_format($DTE['resumen']['totalGravada'], 2) }}</td>
            </tr>
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">Suma total de operaciones: </td>
                <td class="text-right">${{ number_format($DTE['resumen']['subTotalVentas'], 2) }}</td>
            </tr>
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">Monto global Desc., Rebajas y otros a ventas no sujetas: </td>
                <td class="text-right">${{ number_format($DTE['resumen']['descuNoSuj'], 2) }}</td>
            </tr>
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">Monto global Desc., Rebajas y otros a ventas exentas: </td>
                <td class="text-right">${{ number_format($DTE['resumen']['descuExenta'], 2) }}</td>
            </tr>
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">Monto global Desc., Rebajas y otros a ventas gravadas: </td>
                <td class="text-right">${{ number_format($DTE['resumen']['descuGravada'], 2) }}</td>
            </tr>

            @if (isset($DTE['resumen']['tributos']))
                @foreach ($DTE['resumen']['tributos'] as $tributo)
                <tr>
                    <td colspan="4"></td>
                    <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">{{ $tributo['descripcion'] }}: </td>
                    <td class="text-right">${{ number_format($tributo['valor'], 2) }}</td>
                </tr>
                @endforeach
            @endif
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">Sub-Total: </td>
                <td class="text-right">${{ number_format($DTE['resumen']['subTotal'], 2) }}</td>
            </tr>
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">IVA Percibido: (+) </td>
                <td class="text-right">${{ number_format(0, 2) }}</td>
            </tr>
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">IVA Retenido: (-) </td>
                <td class="text-right">${{ number_format($DTE['resumen']['ivaRete1'], 2) }}</td>
            </tr>
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">Retención de Renta: </td>
                <td class="text-right">${{ number_format($DTE['resumen']['reteRenta'], 2) }}</td>
            </tr>
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">Monto Total de la Operación: </td>
                <td class="text-right">${{ number_format($DTE['resumen']['montoTotalOperacion'], 2) }}</td>
            </tr>
            @if ($DTE['resumen']['totalNoGravado'] > 0)
                <tr>
                    <td colspan="4"></td>
                    <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}">Total Otros montos no afectos: </td>
                    <td class="text-right">${{ number_format($DTE['resumen']['totalNoGravado'], 2) }}</td>
                </tr>
            @endif
            <tr>
                <td colspan="4"></td>
                <td colspan="{{ $DTE['resumen']['totalNoGravado'] > 0 ? 5 : 4 }}" class="bg-light"><b>Total a pagar:</b></td>
                <td class="bg-light text-right"><b>${{ number_format($DTE['resumen']['totalPagar'], 2) }}</b></td>
            </tr>
        </tfoot>
    </table>
    <table class="table bordered">
        <tbody>
            <tr>
                <td width="50%"><b>Valor en Letras:</b> {{ $DTE['resumen']['totalLetras'] }}</td>
                <td width="50%">
                    <b>Condición de la operación: </b>
                    @if ($DTE['resumen']['condicionOperacion'] == 2)
                        Crédito a {{ \Carbon\Carbon::parse($registro->fecha)->diffInDays(\Carbon\Carbon::parse($registro->fecha_pago), false) }} días
                    @else
                        Contado
                    @endif
                </td>
            </tr>
        </tbody>
    </table>

</body>
</html>
