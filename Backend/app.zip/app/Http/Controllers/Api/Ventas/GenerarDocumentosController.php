<?php

namespace App\Http\Controllers\Api\Ventas;

use App\Http\Controllers\Controller;
use App\Models\Contabilidad\Partidas\Detalle;
use Illuminate\Http\Request;

use JWTAuth;
use Carbon\Carbon;

use App\Models\Ventas\Venta;
use App\Models\Admin\Empresa;
use App\Models\Admin\Documento;
use App\Models\Ventas\Clientes\Cliente;
use Luecano\NumeroALetras\NumeroALetras;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade as PDF;

use Auth;

class GenerarDocumentosController extends Controller
{

    public function generarDoc($id){

        // Si tiene FE en producción
            $empresa = JWTAuth::parseToken()->authenticate()->empresa()->first();

            if ($empresa->facturacion_electronica && $empresa->fe_ambiente == '01') {
                $venta = Venta::where('id', $id)->with('detalles', 'cliente', 'empresa')->firstOrFail();

                $DTE = $venta->dte;

                if ($DTE) {

                    $venta->qr = 'https://admin.factura.gob.sv/consultaPublica?ambiente='. $DTE['identificacion']['ambiente'] .'&codGen=' . $DTE['identificacion']['codigoGeneracion'] . '&fechaEmi=' . $DTE['identificacion']['fecEmi'];

                    if (
                        isset($empresa->custom_empresa['configuraciones']) &&
                        isset($empresa->custom_empresa['configuraciones']['ticket_en_pdf']) &&
                        $empresa->custom_empresa['configuraciones']['ticket_en_pdf'] == true
                    ) {
                        $venta->pdf = true;
                        
                        $pdf = PDF::loadView('reportes.facturacion.DTE-Ticket', compact('venta', 'DTE'));

                        // Estimar altura:
                           $alto_base = 220; // mm (encabezado, totales, etc.)
                           $alto_por_producto = 30; // mm por línea estimado

                           $total_lineas = $venta->detalles()->count();
                           $alto_total_mm = $alto_base + ($total_lineas * $alto_por_producto);

                           // Convertir mm a puntos (1mm ≈ 2.83465 pt)
                           $alto_total_pt = $alto_total_mm * 2.83465;
                           $ancho_pt = 80 * 2.83465; // 80mm de ancho

                           $pdf->setPaper([0, 0, $ancho_pt, $alto_total_pt]);

                        return $pdf->stream($DTE['identificacion']['codigoGeneracion'] . '.pdf');

                    }else{
                        $venta->pdf = false;
                        return view('reportes.facturacion.DTE-Ticket', compact('venta', 'DTE'));
                    }

                }else{
                    return "El documento no ha sido Emitido";
                }

            }
            
        $venta = Venta::where('id', $id)->with('detalles', 'empresa')->firstOrFail();
        $documento = Documento::findOrfail($venta->id_documento);

        if ($documento->nombre == 'Ticket' || $documento->nombre == 'Recibo') {
            $documento = Documento::findOrfail($venta->id_documento);

            $empresa = Empresa::findOrfail(Auth::user()->id_empresa);

            if (
                isset($empresa->custom_empresa['configuraciones']) &&
                isset($empresa->custom_empresa['configuraciones']['ticket_en_pdf']) &&
                $empresa->custom_empresa['configuraciones']['ticket_en_pdf'] == true
            ) {
                $venta->pdf = true;
                
                $pdf = PDF::loadView('reportes.facturacion.ticket', compact('venta', 'empresa', 'documento'));

                // Estimar altura:
                   $alto_base = 220; // mm (encabezado, totales, etc.)
                   $alto_por_producto = 7; // mm por línea estimado

                   $total_lineas = $venta->detalles()->count();
                   $alto_total_mm = $alto_base + ($total_lineas * $alto_por_producto);

                   // Convertir mm a puntos (1mm ≈ 2.83465 pt)
                   $alto_total_pt = $alto_total_mm * 2.83465;
                   $ancho_pt = 80 * 2.83465; // 80mm de ancho

                   $pdf->setPaper([0, 0, $ancho_pt, $alto_total_pt]);

                return $pdf->stream('ticket.pdf');

            }else{
                $venta->pdf = false;
                return view('reportes.facturacion.ticket', compact('venta', 'empresa', 'documento'));
            }

        }

//        factura
        if ($documento->nombre == 'Factura') {
            $cliente = Cliente::withoutGlobalScope('empresa')->find($venta->id_cliente);

            $empresa = Empresa::findOrfail(Auth::user()->id_empresa);

            $formatter = new NumeroALetras();
            $n = explode(".", number_format($venta->total,2));


            $dolares = $formatter->toWords(floatval(str_replace(',', '',$n[0])));
            $centavos = $formatter->toWords($n[1]);

            //return response()->json($n);

            if(Auth::user()->id_empresa == 38){ //38
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.velo', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 212){ //212
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.fotopro', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 62){ //62
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.hotel-eco', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 84){ //84
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.devetsa', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 75){ //75
                // return View('reportes.facturacion.formatos_empresas.Factura-Biovet', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Biovet', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 104){ //104
                // return View('reportes.facturacion.formatos_empresas.Factura-coloretes', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.factura-Coloretes', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 11){ //11
                // return View('reportes.facturacion.formatos_empresas.Factura-organika', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-organika', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper([0, 0, 365.669, 566.929133858]);
            }
            elseif(Auth::user()->id_empresa == 12){ //12
                // return View('reportes.facturacion.formatos_empresas.Factura-Ayakahuite', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Ayakahuite', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper([0, 0, 365.669, 566.929133858]);
            }
            elseif(Auth::user()->id_empresa == 128){ //128
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.kiero-factura', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper([0, 0, 283.46, 765.35]);
            }
            elseif(Auth::user()->id_empresa == 135){ //135
                // return View('reportes.facturacion.formatos_empresas.Dentalkey-factura', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Dentalkey-factura', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper([0, 0, 609.45, 467.72]);
            } 
            elseif(Auth::user()->id_empresa == 136){ //136 OK V2
                return View('reportes.facturacion.formatos_empresas.Factura-Emerson', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Emerson', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper([0, 0, 365.669, 609.4488]);
            }
            elseif(Auth::user()->id_empresa == 149){ //149 OK V2
                return View('reportes.facturacion.formatos_empresas.Factura-Natura', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Natura', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 187){//187
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Express-Shopping', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 130){//130
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-TecnoGadget', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('Legal', 'landscape');
            }
            elseif(Auth::user()->id_empresa == 177){//177
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Credicash', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 24 ){ //24
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Via-del-Mar', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 174 ){ //174
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Consultora-Raices', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 59 ){ //59
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Smartpyme', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 244 ){ //244 OK V2
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-keke', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 210 ){ //210
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Arborea-desg', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 229 ){ //229
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Norbin', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 50 ){ //50
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.RefriAcTotal-Factura', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 274 ){ //274
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Flat-Speed-Cars', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 321 ){ //321
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Importaciones-Blanco', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 346 ){ //346
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Vape-Store', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 154 || Auth::user()->id_empresa == 397 || Auth::user()->id_empresa == 398 || Auth::user()->id_empresa == 397 ){ //154
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Estilos-Salon', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 396 ){ //154
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Estilos-Salon-SA-CV', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 367 ){ //367
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Clinica', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 250 ){ //250
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Full-Solution', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('Legal', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 400 ){ //400
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Zoe-Cosmetics', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 420 ){ //420
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Inversiones-Andre', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 315 ){ //315
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Factura-Sistemas-de-Impresion', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            else{
                // return View('reportes.facturacion.formatos_empresas.factura', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.factura', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }


            return $pdf->stream($empresa->nombre . '-factura-' . $venta->correlativo . '.pdf');
        }

//        factura sujeto excluido
        if ($documento->nombre == 'Sujeto excluido') {
            $cliente = Cliente::withoutGlobalScope('empresa')->find($venta->id_cliente);

            $empresa = Empresa::findOrfail(Auth::user()->id_empresa);

            $formatter = new NumeroALetras();
            $n = explode(".", number_format($venta->total,2));


            $dolares = $formatter->toWords(floatval(str_replace(',', '',$n[0])));
            $centavos = $formatter->toWords($n[1]);

            //return response()->json($n);

            if(Auth::user()->id_empresa == 210){ //210
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Sujeto-Excluido-fact-Arborea-desg', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 367 ){ //367
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Sujeto-Excluido-Clinica', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 400 ){ //400
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Sujeto-Zoe-Cosmetics', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            else{
                // return View('reportes.facturacion.formatos_empresas.factura', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.factura-sujeto-excluido', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }


            return $pdf->stream($empresa->nombre . '-factura-' . $venta->correlativo . '.pdf');
        }

//          credito fiscal
        if ($documento->nombre == 'Crédito fiscal') {
            $cliente = Cliente::withoutGlobalScope('empresa')->findOrfail($venta->id_cliente);

            $empresa = Empresa::findOrfail(Auth::user()->id_empresa);

            $formatter = new NumeroALetras();
            $n = explode(".", number_format($venta->total,2));


            $dolares = $formatter->toWords(floatval(str_replace(',', '',$n[0])));
            $centavos = $formatter->toWords($n[1]);

            if(Auth::user()->id_empresa == 24){ //24
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.vetvia-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 212){ //212
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-FotoPro', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 38){ //38
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.velo-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 62){ //62
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.hotel-eco-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 128){ //128
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.kiero-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper([0, 0, 283, 765]);
            }
            elseif(Auth::user()->id_empresa == 135){ //135
                // return View('reportes.facturacion.formatos_empresas.Dentalkey-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Dentalkey-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper([0, 0, 609.45, 467.72]);
            }
            elseif(Auth::user()->id_empresa == 136){ //136
                // return View('reportes.facturacion.formatos_empresas.destroyesa-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.destroyesa-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper([0, 0, 297.64, 382.68]);
            }
            elseif(Auth::user()->id_empresa == 158){//158
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.Guaca-Mix-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 177){//177
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Credicash', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 187){//187
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Express-Shopping', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait'); 
            } 
            elseif(Auth::user()->id_empresa == 130){//130
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-TecnoGadget', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('Legal', 'landscape');
            }
            elseif(Auth::user()->id_empresa == 84){ //84
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.devetsa-cff', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 59){ //59
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.smartpyme-ccf', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 210){ //210
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Arborea-Design', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 244){ //210
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-keke', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 229){ //229
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Norbin', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 315){ //315
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Sistema-Impresiones', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 313 ){ //313
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-American-Laundry', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 274 ){ //274
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Flat-Speed-Cars', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 321 ){ //321
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Importaciones-Blanco', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 290 ){ //290
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Grupo-Lievano', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 367 ){ //367
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Clinica', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 250 ){ //250
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Full-Solution', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('Legal', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 400 ){ //400
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Zoe-Cosmetics', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            elseif(Auth::user()->id_empresa == 315 ){ //315
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.CCF-Sistemas-de-Impresion', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
            else{
                $pdf = PDF::loadView('reportes.facturacion.formatos_empresas.credito', compact('venta', 'empresa', 'cliente', 'dolares', 'centavos'));
                $pdf->setPaper('US Letter', 'portrait');
            }
  
            return $pdf->stream($empresa->nombre . '-credito-' . $venta->correlativo . '.pdf');
        }

        return "No hay un formato para este tipo de documento de venta.";

    }

    public function anularDoc(){

        return view('reportes.anulacion');

    }

}
